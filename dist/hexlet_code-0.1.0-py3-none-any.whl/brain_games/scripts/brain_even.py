import random


def even_or_add(number):
    return number % 2 == 0


def main():
    print('Welcome to the Brain Games!')
    name = input('May I have your name? ')
    print(f'Hello, {name}!')
    print('Answer "yes" if the number is even, otherwise answer "no"')

    for _ in range(3):
        random_number = random.randint(1,100)
        correct_answer = 'yes' if even_or_add(random_number) else 'no'

        print(f'Question: {random_number}')
        player_answer = input('Your answer: ')

        if player_answer.lower() == correct_answer:
            print('Correct!')
        else:
            print(f"'{player_answer}' is wrong answer ;(. Correct answer was '{correct_answer}'.")
            print(f"Let's try again, {name}!")
            return

    print(f'Congratulations, {name}!')


if __name__ == "__main__":
    main()
