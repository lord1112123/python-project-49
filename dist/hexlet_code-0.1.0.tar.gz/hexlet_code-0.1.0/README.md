### Hexlet tests and linter status:
[![Actions Status](https://github.com/lord1112123/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/lord1112123/python-project-49/actions)

<a href="https://codeclimate.com/github/lord1112123/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/930add31641aa2010362/maintainability" /></a>
